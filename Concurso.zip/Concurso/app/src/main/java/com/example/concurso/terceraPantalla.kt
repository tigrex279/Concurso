package com.example.concurso

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.RadioButton
import android.widget.RadioGroup

class terceraPantalla : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tercera_pantalla)
    }

    fun radioOpcion() : String{

        var palabra:String
        var radio = findViewById<RadioButton>(R.id.Escopeta)

        if (radio.isChecked) {
            palabra = "Escopetas"
            return palabra
        } else{
          radio = findViewById(R.id.Fusil)
            if (radio.isChecked) {
                palabra = "Fusil"
                return palabra
            }
            else{
                radio = findViewById(R.id.Snipper)
                if (radio.isChecked) {
                    palabra = "Francotirador/Arco"
                    return palabra
                }
                else{
                    radio = findViewById(R.id.Explosivo)
                    if (radio.isChecked) {
                        palabra = "Lanzamisiles,lanzagranadas"
                        return palabra
                    }
                    else {
                        radio = findViewById(R.id.subF)
                        if (radio.isChecked) {
                            palabra = "Subfusiles"
                            return palabra
                        } else {
                            radio = findViewById(R.id.energia)
                            if (radio.isChecked) {
                                palabra = "Arma energia"
                                return palabra
                            } else {
                                radio = findViewById(R.id.meele)
                                if (radio.isChecked) {
                                    palabra = "armas corta distancia"
                                    return palabra
                                }
                            }
                        }
                    }
                }
            }
        }
        return ""
    }
    fun ultimaPregunta(view: View){
        val grupo = findViewById<RadioGroup>(R.id.armas)
        var id: Int = grupo.checkedRadioButtonId
        if(id != -1){
            val intent = Intent(this, cuartaPantalla::class.java).apply {
                val nombre = intent.getStringExtra("usuario")
                val check = intent.getStringExtra("check")
                putExtra("usuario", nombre)
                putExtra("check", check)
                putExtra("radio", radioOpcion())
            }
            startActivity(intent)
        }
    }
}